<?php

header('Content-Type', 'application/x-www-form-urlencoded');
header('Access-Control-Allow-Origin: *');  

$files = glob('progress*.png'); // get all file names
foreach($files as $file){ // iterate files
  if(is_file($file))
    unlink($file); // delete file
}
if(!empty($_FILES['file']))
  {
	$idx = 0;
    $path = "";
    $path = $path . "arg0.gif";
    if(move_uploaded_file($_FILES['file']['tmp_name'], $path)) {
		exec("convert.exe arg0.gif progress.png");
		$files = glob('progress*.png'); // get all file names
		foreach($files as $file){ // iterate files
		  if(is_file($file))
		    $idx++;
		}
		echo $idx;
		
		
		$str = "convert.exe +append";
		for($i = 0;$i < $idx;$i++)
		{
			$str .=" progress-".$i.".png";
		}
		$str.=" result.jpg";
		
		exec($str);
		copy("result.jpg", "d:\\16\\fabricjs-gif\\src\\assets\\image\\result.jpg");
    } else{
        echo "There was an error uploading the file, please try again!";
    }
  }
	
	
?>





